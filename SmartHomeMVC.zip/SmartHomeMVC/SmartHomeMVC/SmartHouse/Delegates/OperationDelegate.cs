﻿namespace SmartHome
{
    public delegate void OperationDoneDelegate(Device source);
}
